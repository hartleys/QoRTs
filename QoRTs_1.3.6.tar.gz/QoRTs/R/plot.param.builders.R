
###########################################################################################################################################################################
###########################################################################################################################################################################
######################################################### EXTERNAL-FACING:
###########################################################################################################################################################################
###########################################################################################################################################################################

#highlight.by, color.highlighted.by, plot.type, offset.by = color.highlighted.by,  merge.offset.outgroup = TRUE, pch.matched.with.color = TRUE

build.plotter.highlightSample.colorByLane <- function(curr.sample, res, 
                                                      plotter.params = list(), 
                                                      merge.offset.outgroup = TRUE,
                                                      lane.column.name = "lane.ID"){
   pch.matched.with.color <- TRUE
   if(! (curr.sample %in% res@decoder$sample.ID)){
      stop("FATAL ERROR! ","Cannot find sample ", curr.sample," in the sample list!");
   }
   base.defaultParams <- QoRTs.default.plotting.params;
   defaultParams <- merge.plotting.params(base.defaultParams,list());
   final.params <- merge.plotting.params(defaultParams,plotter.params);
   compiled.params <- compile.plotting.params(final.params);
   
   print(compiled.params@plot.annotation)
   
   return(build.plotter.highlight.and.color(curr.highlight = curr.sample, 
                                            res = res, 
                                            compiled.params = compiled.params,
                                            highlight.by = res@decoder$sample.ID, 
                                            color.highlighted.by = res@decoder[[lane.column.name]], 
                                            plot.type = "highlightSample.colorByLane", 
                                            merge.offset.outgroup = merge.offset.outgroup,
                                            pch.matched.with.color = pch.matched.with.color));
}

#########################################################
build.plotter.highlightGroup <- function(highlight.set, res, title.highlight.name = "Custom Subgroup", highlight.param = "sample.ID", 
                                         plotter.params = list(), merge.offset.outgroup = TRUE){
   
   if(is.null(res@decoder[[highlight.param]])){
      stop("FATAL ERROR! ","Cannot find parameter ", highlight.param," in the decoder!");
   }
   
   base.defaultParams <- QoRTs.default.plotting.params;
   defaultParams <- merge.plotting.params(base.defaultParams,list());
   final.params <- merge.plotting.params(defaultParams,plotter.params);
   compiled.params <- compile.plotting.params(final.params);
   
   return(build.plotter.highlight(curr.highlight = highlight.set, 
                                  res = res, 
                                  title.highlight.name = title.highlight.name,
                                  compiled.params = compiled.params,
                                  highlight.by = res@decoder$sample.ID, 
                                  plot.type = "highlightSample", 
                                  offset.by = res@decoder$lane.ID, 
                                  merge.offset.outgroup = merge.offset.outgroup));
}
#########################################################

build.plotter.highlightSample <- function(curr.sample, res, plotter.params = list(), merge.offset.outgroup = TRUE){
   if(! (curr.sample %in% res@decoder$sample.ID)){
      stop("FATAL ERROR! ","Cannot find sample ", curr.sample," in the sample list!");
   }
   base.defaultParams <- QoRTs.default.plotting.params;
   defaultParams <- merge.plotting.params(base.defaultParams,list());
   final.params <- merge.plotting.params(defaultParams,plotter.params);
   compiled.params <- compile.plotting.params(final.params);
   
   return(build.plotter.highlight(curr.sample, 
                                  res = res, 
                                  compiled.params = compiled.params,
                                  highlight.by = res@decoder$sample.ID, 
                                  plot.type = "highlightSample", 
                                  offset.by = res@decoder$lane.ID, 
                                  merge.offset.outgroup = merge.offset.outgroup));
}

#########################################################

build.plotter.colorByLane <- function(res, plotter.params = list()){
   base.defaultParams <- QoRTs.default.plotting.params;
   defaultParams <- merge.plotting.params(base.defaultParams,list(std.lines.alpha = 125));
   final.params <- merge.plotting.params(defaultParams,plotter.params);
   compiled.params <- compile.plotting.params(final.params);
   
   return(build.plotter.color( 
                                            res = res, 
                                            compiled.params = compiled.params,
                                            color.by = res@decoder$lane.ID, 
                                            plot.type = "colorByLane",
                                            color.by.title.name = "Lane"));
}

#########################################################

build.plotter.colorByGroup <- function(res, plotter.params = list()){
   base.defaultParams <- QoRTs.default.plotting.params;
   defaultParams <- merge.plotting.params(base.defaultParams,list(std.lines.alpha = 125));
   final.params <- merge.plotting.params(defaultParams,plotter.params);
   compiled.params <- compile.plotting.params(final.params);
   
   return(build.plotter.color(
                                            res = res, 
                                            compiled.params = compiled.params,
                                            color.by = res@decoder$group.ID, 
                                            plot.type = "colorByGroup",
                                            color.by.title.name = "Group"));
}

#########################################################

build.plotter.colorBySample <- function(res, plotter.params = list()){
   base.defaultParams <- QoRTs.default.plotting.params;
   defaultParams <- merge.plotting.params(base.defaultParams,list(std.lines.alpha = 125));
   final.params <- merge.plotting.params(defaultParams,plotter.params);
   compiled.params <- compile.plotting.params(final.params);
   
   
   
   return(build.plotter.color( 
                                            res = res, 
                                            compiled.params = compiled.params,
                                            color.by = res@decoder$sample.ID, 
                                            plot.type = "colorBySample",
                                            color.by.title.name = "Sample"));
}

#########################################################

build.plotter.basic <- function(res, plotter.params = list()){
   base.defaultParams <- QoRTs.default.plotting.params;
   defaultParams <- merge.plotting.params(base.defaultParams,list(std.lines.alpha = 150, std.points.alpha = 150, std.color = "blue", std.lines.lty = 1));
   final.params <- merge.plotting.params(defaultParams,plotter.params);
   compiled.params <- compile.plotting.params(final.params);
   
   build.plotter.basic.helper(res,res@decoder$lane.ID, compiled.params = compiled.params ,plot.type = "summary");
}

#########################################################
#Advanced use:
#########################################################

build.plotter.colorByX <- function(res, color.by.name, color.by.title.name = color.by.name, plotter.params = list()){
  base.defaultParams <- QoRTs.default.plotting.params;
  defaultParams <- merge.plotting.params(base.defaultParams,list(std.lines.alpha = 125));
  final.params <- merge.plotting.params(defaultParams,plotter.params);
  compiled.params <- compile.plotting.params(final.params);
  
  if(! (color.by.name %in% names(res@decoder))){
    stop(paste0("Fatal error: Cannot find field \"",color.by.name,"\" in the decoder! Check the spelling and capitalization?"));
  }
  colorBy <- res@decoder[[color.by.name]];
  colorBy <- ifelse(is.na(colorBy),"NA",colorBy);
  
   return(build.plotter.color(
                                            res = res, 
                                            compiled.params = compiled.params,
                                            color.by = colorBy, 
                                            plot.type = "colorByX",
                                            color.by.title.name = color.by.title.name));
}

#########################################################

build.plotter.advanced <- function(res, 
                                   colorBy = NULL,
                                   color.title = "?",
                                   highlightBy = NULL, 
                                   highlight = "CURR", 
                                   highlightTitle.singular = NULL,
                                   highlightTitle.plural = highlightTitle.singular,
                                   outgroup.title = "Other",
                                   plotter.params = list()){
  if(is.null(highlightBy) && is.null(colorBy)){
    return(build.plotter.basic(res=res,plotter.params=plotter.params));
  } else if(is.null(highlightBy)){
    base.defaultParams <- QoRTs.default.plotting.params;
    defaultParams <- merge.plotting.params(base.defaultParams,list(std.lines.alpha = 125));
    final.params <- merge.plotting.params(defaultParams,plotter.params);
    compiled.params <- compile.plotting.params(final.params);
    
    if(length(colorBy) == nrow(res@decoder) && any(names(colorBy) != res@decoder$unique.ID)){
        stop("Error: colorBy vector must be named with unique ID's and be in the correct order!");
    }
    
    colorBy <- ifelse(is.na(colorBy),"NA",colorBy);
    
    return(build.plotter.color(
                                            res = res, 
                                            compiled.params = compiled.params,
                                            color.by = colorBy, 
                                            plot.type = "colorByX",
                                            color.by.title.name = color.title,
                                            title.annotations = list( 
                                                             color.by.title.name = color.title)
                                            ));
  } else if(is.null(colorBy)){
    if(is.null(highlightTitle.singular)) highlightTitle.singular <- deparse(substitute(highlightBy));
    if(is.null(highlightTitle.plural))   highlightTitle.plural <- highlightTitle.singular;
  
     if(length(highlightBy) == nrow(res@decoder) && any(names(highlightBy) != res@decoder$unique.ID)){
        stop("Error: highlightBy vector must be named with unique.ID's and be in the same order as res@decoder$unique.ID");
     }
   
     base.defaultParams <- QoRTs.default.plotting.params;
     defaultParams <- merge.plotting.params(base.defaultParams,list());
     final.params <- merge.plotting.params(defaultParams,plotter.params);
     compiled.params <- compile.plotting.params(final.params);
   
     return(build.plotter.highlight(highlight, 
                                  res = res, 
                                  compiled.params = compiled.params,
                                  highlight.by = highlightBy, 
                                  plot.type = "highlightByX", 
                                  offset.by = ifelse(highlightBy == highlight,"1","0"), 
                                  merge.offset.outgroup = TRUE,
                                    title.annotations = list(highlight=highlight, 
                                                             highlight.by.name=highlightTitle.plural,
                                                             highlight.by.title.name = highlightTitle.singular),
                                  outgroup.name = paste0(outgroup.title),
                                  highlightTitle.plural = highlightTitle.plural
                                  ));
  } else {
    if(is.null(highlightTitle.singular)) highlightTitle.singular <- deparse(substitute(highlightBy));
    if(is.null(highlightTitle.plural))   highlightTitle.plural <- highlightTitle.singular;
  
    base.defaultParams <- QoRTs.default.plotting.params;
    defaultParams <- merge.plotting.params(base.defaultParams,list(std.lines.alpha = 125));
    final.params <- merge.plotting.params(defaultParams,plotter.params);
    compiled.params <- compile.plotting.params(final.params);
  
    if(length(colorBy) == nrow(res@decoder) && any(names(colorBy) != res@decoder$unique.ID)){
        stop("Error: colorBy vector must be named with unique ID's and be in the correct order!");
    }
     if(length(highlightBy) == nrow(res@decoder) && any(names(highlightBy) != res@decoder$unique.ID)){
        stop("Error: highlightBy vector must be named with unique.ID's and be in the same order as res@decoder$unique.ID");
     }
  
    colorBy     <- ifelse(is.na(colorBy),"NA",colorBy);
    highlightLogical <- f.na(highlightBy == highlight);
    highlightBy[!highlightLogical] <- outgroup.title;
  
    color.highlighted.by <- colorBy;
  
    plotter <-
    build.plotter.highlight.and.color(curr.highlight = highlight, 
                                    res=res, 
                                    compiled.params=compiled.params, 
                                    highlight.by = highlightBy, 
                                    color.highlighted.by = color.highlighted.by, 
                                    title.annotations = list(highlight=highlight, 
                                                             highlight.by.name=highlightTitle.plural,
                                                             highlight.by.title.name = highlightTitle.singular, 
                                                             color.by.title.name = color.title),
                                    plot.type="colorByXhighlightByY", 
                                    offset.by = color.highlighted.by, 
                                    merge.offset.outgroup = TRUE, 
                                    pch.matched.with.color = TRUE, 
                                    highlighted.by.name = highlightTitle.plural)
    return(plotter)
  }
}

#########################################################
#########################################################

build.plotter.colorByVector <- function(res, colorBy, color.by.title.name = "?", plotter.params = list()){
  base.defaultParams <- QoRTs.default.plotting.params;
  defaultParams <- merge.plotting.params(base.defaultParams,list(std.lines.alpha = 125));
  final.params <- merge.plotting.params(defaultParams,plotter.params);
  compiled.params <- compile.plotting.params(final.params);
  
  
  if(is.null(colorBy) || any(names(colorBy) != res@decoder$unique.ID)){
      stop("Error: colorBy vector must be named with unique ID's and be in the correct order!");
  }
  
  colorBy <- ifelse(is.na(colorBy),"NA",colorBy);

  return(build.plotter.color(
                                            res = res, 
                                            compiled.params = compiled.params,
                                            color.by = colorBy, 
                                            plot.type = "colorByX",
                                            color.by.title.name = color.by.title.name));
}


build.plotter.colorAndHighlightByVector <- function(res, 
                                                    colorBy, 
                                                    color.by.title.name = "?",
                                                    highlightBy, 
                                                    highlight = "CURR", 
                                                    highlight.by.name = NULL,
                                                    highlight.by.title.name = highlight.by.name,
                                                    plotter.params = list()){
  if(is.null(highlight.by.name)) highlight.by.name <- deparse(substitute(highlightBy));
  if(is.null(highlight.by.title.name)) highlight.by.title.name <- highlight.by.name;
  
  base.defaultParams <- QoRTs.default.plotting.params;
  defaultParams <- merge.plotting.params(base.defaultParams,list(std.lines.alpha = 125));
  final.params <- merge.plotting.params(defaultParams,plotter.params);
  compiled.params <- compile.plotting.params(final.params);
  
  colorBy     <- ifelse(is.na(colorBy),"NA",colorBy);
  highlightLogical <- f.na(highlightBy == highlight);
  highlightBy[!highlightLogical] <- "OTHER";
  
  color.highlighted.by <- colorBy;
  
  plotter <-
  build.plotter.highlight.and.color(curr.highlight = highlight, 
                                    res=res, 
                                    compiled.params=compiled.params, 
                                    highlight.by = highlightBy, 
                                    color.highlighted.by = color.highlighted.by, 
                                    title.annotations = list(highlight=highlight, highlight.by.name=highlight.by.name,highlight.by.title.name = highlight.by.title.name, color.by.title.name = color.by.title.name),
                                    plot.type="colorByXhighlightByY", 
                                    offset.by = color.highlighted.by, 
                                    merge.offset.outgroup = TRUE, 
                                    pch.matched.with.color = TRUE, 
                                    highlighted.by.name = highlight.by.name)
  return(plotter)
}


build.plotter.colorAndHighlightBySampleVector <- function(res, colorBy, color.by.title.name = "?",
                                                    highlightList,
                                                    plotter.params = list()){
  base.defaultParams <- QoRTs.default.plotting.params;
  defaultParams <- merge.plotting.params(base.defaultParams,list(std.lines.alpha = 125));
  final.params <- merge.plotting.params(defaultParams,plotter.params);
  compiled.params <- compile.plotting.params(final.params);
  
  curr.highlight="CURR";
  highlight.by <- rep("OTHER",length(res@lanebam.list));
  highlight.by[res@decoder$sample.ID %in% highlightList] <- "CURR";
  
  if(! all(  res@decoder$sample.ID[res@decoder$sample.ID %in% highlightList] %in% names(colorBy))){
      stop("build.plotter.colorAndHighlightByVector: Malformed colorBy.");
  }
  
  color.highlighted.by <- sapply(res@decoder$sample.ID, function(samp){
      if(samp %in% names(colorBy)){ 
          colorBy[[samp]]
      } else{ 
          NA
      }
  })
  
  plotter <-
  build.plotter.highlight.and.color(curr.highlight = "CURR", 
                                    res=res, 
                                    compiled.params=compiled.params, 
                                    highlight.by = highlight.by, 
                                    color.highlighted.by = color.highlighted.by, 
                                    plot.type="colorByX", 
                                    offset.by = color.highlighted.by, 
                                    merge.offset.outgroup = TRUE, 
                                    pch.matched.with.color = TRUE, 
                                    highlighted.by.name = color.by.title.name)
  return(plotter)
}

#


###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################
######################################################### INTERNAL:
###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################
###########################################################################################################################################################################

build.plotter.basic.helper <- function(res, offset.by, compiled.params, plot.type,title.annotations=list()){
  if(! is.null(check.isValid(res))){
    #THROW AN ERROR!
    stop("Error parsing results: ", check.isValid(res));
  }
  
  #plotParams <- new("QoRT_Plotter");
  #plotParams@res <- res;
  #plotParams@plot.type <- plot.type;
  title.highlight.name <- "Summary";
  showLegend <- FALSE;
  nvc.colors <- compiled.params@nvc.colors;
  nvc.colors.light <- compiled.params@nvc.colors;
  
  lanebam.ct <- length(offset.by);
  
  legend.params <- data.frame(name = c(),
                                         lines.col = c(),
                                         lines.lty = c(),
                                         points.pch = c(),
                                         points.col = c(),
                                         stringsAsFactors=F
  );
  
  offset.by.vals <- sort(unique(offset.by));
  offset.ct <- length(offset.by.vals);
  if(offset.ct %% 2 == 0){
    offsets <- (((1:offset.ct) / (offset.ct)) );
    offsets <- offsets - ( offsets[ offset.ct / 2  + 1] + offsets[ offset.ct / 2 ]  ) / 2
  } else {
    offsets <- (((1:offset.ct) / (offset.ct)) - 0.5  );
    offsets <- offsets - offsets[ (offset.ct + 1) / 2 ];
  }
  
  lanebam.offset.indices <- sapply(1:lanebam.ct, FUN=function(i){
    which(offset.by.vals == offset.by[i])
  });
  lanebam.offsets <- offsets[lanebam.offset.indices];

  lanebam.params <- data.frame( plot.priority = rep(2,lanebam.ct),
                                           unique.ID = res@decoder$unique.ID,
                                           lines.col = rep(compiled.params@highlight.color[1], lanebam.ct),
                                           points.col = rep(compiled.params@highlight.color[1], lanebam.ct),
                                           points.pch = rep(compiled.params@highlight.points.pch[1], lanebam.ct),
                                           lines.lty = rep(compiled.params@highlight.lines.lty[1], lanebam.ct),
                                           lines.lwd = rep(compiled.params@highlight.lines.lwd[1], lanebam.ct),
                                           lines.alpha = rep(compiled.params@highlight.lines.alpha[1], lanebam.ct),
                                           points.alpha = rep(compiled.params@highlight.points.alpha[1], lanebam.ct),
                                           horiz.offsets = lanebam.offsets,
                                           vert.offsets = lanebam.offsets,
                                           stringsAsFactors=F
  );
  lanebam.params$lines.tcol  <- color2transparent(lanebam.params$lines.col,lanebam.params$lines.alpha);
  lanebam.params$points.tcol <- color2transparent(lanebam.params$points.col,lanebam.params$points.alpha);
  
  plotParams <- generate.plotter(res = res, plot.type = plot.type, title.highlight.name = title.highlight.name, legend.params = legend.params, showLegend = showLegend, nvc.colors = nvc.colors, nvc.colors.light = nvc.colors.light, lanebam.params = lanebam.params,randomize.plot.order=compiled.params@randomize.plot.order,
                                 title.annotations=c(title.annotations,compiled.params@plot.annotation))
  return(plotParams);
}

##################################################################################################################
##################################################################################################################
##################################################################################################################


build.plotter.advanced.internal <- function(curr.highlight, res, compiled.params, highlight.by, color.highlighted.by, plot.type, offset.by = color.highlighted.by, merge.offset.outgroup = TRUE, pch.matched.with.color = TRUE, highlighted.by.name = "Samples",title.annotations=list()){
  if(! is.null(check.isValid(res))){
    #THROW AN ERROR!
    stop("Error parsing results: ", check.isValid(res));
  }
  if(length(highlight.by) != length(color.highlighted.by)) stop("error: length(highlight.by) != length(color.highlighted.by)\n   length(highlight.by) = ",length(highlight.by),", length(color.highlighted.by) = ",length(color.highlighted.by));
  if(length(highlight.by) != length(res@decoder$unique.ID)) stop("error: length(highlight.by) != length(res@decoder$unique.ID)\n   length(highlight.by) = ",length(highlight.by),", length(res@decoder$unique.ID) = ",length(res@decoder$unique.ID));
   if(! (curr.highlight %in% highlight.by)){
      stop("FATAL ERROR! ","Cannot find highlighted element ", curr.highlight," in the highlight list!");
   }
  
  #plotParams <- new("QoRT_Plotter");
  #plotParams@res <- res;
  #plotParams@plot.type <- plot.type;
  title.highlight.name <- curr.highlight;
  showLegend <- compiled.params@showLegend;
  nvc.colors <- compiled.params@nvc.colors;
  nvc.colors.light <- compiled.params@nvc.colors.light;
  
  is.highlighted <- highlight.by == curr.highlight;
  lanebam.ct <- length(highlight.by);
  hl.by.factor <- color.highlighted.by[is.highlighted ];
  hl.by.factor.levels <- sort(unique(hl.by.factor));
  
  if(length(hl.by.factor.levels) > length(compiled.params@by.colors)) {
    message("WARNING WARNING WARNING: Too many categories to color! (Max = ",length(compiled.params@by.colors),", curr = ",length(hl.by.factor.levels),") Add more colors? Falling back to a rainbow palette");
    compiled.params@by.colors <- rainbow(length(hl.by.factor.levels));
  } 
  if(pch.matched.with.color){
    if(length(hl.by.factor.levels) > length(compiled.params@by.pch)){
      message("WARNING WARNING WARNING: Too many categories to mark distinct with pch! (Max = ",length(compiled.params@by.pch),", curr = ",length(hl.by.factor.levels),") Add more colors? Falling back to a repeating pattern.");
      compiled.params@by.pch <- rep(compiled.params@by.pch, ceiling( length(hl.by.factor.levels) / length(compiled.params@by.pch)));
    }
    legend.points.pch <- compiled.params@by.pch[1:length(hl.by.factor.levels)];
  } else {
    legend.points.pch <- rep(compiled.params@highlight.points.pch[1], length(hl.by.factor.levels));
  }

  legend.params <- data.frame(name = c(hl.by.factor.levels, paste0("Other ",highlighted.by.name)),
                                         lines.col = c(compiled.params@by.colors[1:length(hl.by.factor.levels)], compiled.params@highlight.color[2]),
                                         lines.lty = c(rep(compiled.params@highlight.lines.lty[1],length(hl.by.factor.levels)), compiled.params@highlight.lines.lty[2]),
                                         points.pch = c(legend.points.pch, compiled.params@highlight.points.pch[2]),
                                         points.col = c(compiled.params@by.colors[1:length(hl.by.factor.levels)], compiled.params@highlight.color[2]),
                                         stringsAsFactors=F
  );
  
  lines.col <- sapply(1:lanebam.ct, FUN=function(i){
    if(! is.highlighted[i]){ return(compiled.params@highlight.color[2]);
    } else {return( legend.params$lines.col[ legend.params$name == color.highlighted.by[i] ] );}
  });
  points.col <- sapply(1:lanebam.ct, FUN=function(i){
    if(! is.highlighted[i]){ return(compiled.params@highlight.color[2]);
    } else {return( legend.params$points.col[ legend.params$name == color.highlighted.by[i] ] );}
  });

  if(pch.matched.with.color){
    #message("!!!");
    if(length(hl.by.factor.levels) > length(compiled.params@by.pch)) stop("to many categories in by.colors! Add more pch values to compiled.params@by.pch!");
    points.pch <- sapply(1:lanebam.ct, FUN=function(i){
      if(! is.highlighted[i]){ return(compiled.params@highlight.points.pch[2]);
      } else {return( legend.params$points.pch[ legend.params$name == color.highlighted.by[i] ] );}
    });
    #message(paste("compiled.params@highlight.points.pch: ",compiled.params@highlight.points.pch,collapse=","));
    #message(paste("compiled.params@highlight.points.pch: ",compiled.params@highlight.points.pch,collapse=","));
    #message(paste("points.pch: ",points.pch,collapse=","));
  } else {
    points.pch <- ifelse(is.highlighted, compiled.params@highlight.points.pch[1], compiled.params@highlight.points.pch[2])
  }


  
  if(merge.offset.outgroup){
    offset.by.vals <- sort(unique(offset.by[is.highlighted]));
    if( all(offset.by %in% offset.by.vals)){
      offset.ct <- length(offset.by.vals) ;
    } else {
      offset.ct <- length(offset.by.vals) + 1;
    }
  } else {
    offset.by.vals <- sort(unique(offset.by));
    offset.ct <- length(offset.by.vals) ;
  }
  if(offset.ct %% 2 == 0){
    offsets <- (((1:offset.ct) / (offset.ct)) );
    offsets <- offsets - ( offsets[ offset.ct / 2  + 1] + offsets[ offset.ct / 2 ]  ) / 2
  } else {
    offsets <- (((1:offset.ct) / (offset.ct)) - 0.5  );
    offsets <- offsets - offsets[ (offset.ct + 1) / 2 ];
  }
  
  lanebam.offset.indices <- sapply(1:lanebam.ct, FUN=function(i){
    if(any(offset.by.vals == offset.by[i])){
      which(offset.by.vals == offset.by[i]);
    } else {
      offset.ct;
    }
  });
  lanebam.offsets <- offsets[lanebam.offset.indices];

  lanebam.params <- data.frame( plot.priority = ifelse(is.highlighted, 2,1),
                                           unique.ID = res@decoder$unique.ID,
                                           lines.col = lines.col,
                                           points.col = points.col,
                                           points.pch = points.pch,
                                           lines.lty = ifelse(is.highlighted, compiled.params@highlight.lines.lty[1], compiled.params@highlight.lines.lty[2]),
                                           lines.lwd = ifelse(is.highlighted, compiled.params@highlight.lines.lwd[1], compiled.params@highlight.lines.lwd[2]),
                                           lines.alpha = ifelse(is.highlighted, compiled.params@highlight.lines.alpha[1], compiled.params@highlight.lines.alpha[2]),
                                           points.alpha = ifelse(is.highlighted, compiled.params@highlight.points.alpha[1], compiled.params@highlight.points.alpha[2]),
                                           horiz.offsets = lanebam.offsets,
                                           vert.offsets = lanebam.offsets,
                                           stringsAsFactors=F
  );
  lanebam.params$lines.tcol  <- color2transparent(lanebam.params$lines.col,lanebam.params$lines.alpha);
  lanebam.params$points.tcol <- color2transparent(lanebam.params$points.col,lanebam.params$points.alpha);
  
  plotParams <- generate.plotter(res = res, plot.type = plot.type, title.highlight.name = title.highlight.name, legend.params = legend.params, showLegend = showLegend, nvc.colors = nvc.colors, nvc.colors.light = nvc.colors.light, lanebam.params = lanebam.params,randomize.plot.order=compiled.params@randomize.plot.order,
                                 title.annotations=c(title.annotations,compiled.params@plot.annotation))
  return(plotParams);
}

##################################################################################################################
##################################################################################################################
##################################################################################################################

build.plotter.highlight.and.color <- function(curr.highlight, res, compiled.params, highlight.by, color.highlighted.by, plot.type, offset.by = color.highlighted.by, merge.offset.outgroup = TRUE, pch.matched.with.color = TRUE, highlighted.by.name = "Samples",title.annotations=list()){
  if(! is.null(check.isValid(res))){
    #THROW AN ERROR!
    stop("Error parsing results: ", check.isValid(res));
  }
  if(length(highlight.by) != length(color.highlighted.by)) stop("error: length(highlight.by) != length(color.highlighted.by)\n   length(highlight.by) = ",length(highlight.by),", length(color.highlighted.by) = ",length(color.highlighted.by));
  if(length(highlight.by) != length(res@decoder$unique.ID)) stop("error: length(highlight.by) != length(res@decoder$unique.ID)\n   length(highlight.by) = ",length(highlight.by),", length(res@decoder$unique.ID) = ",length(res@decoder$unique.ID));
   if(! (curr.highlight %in% highlight.by)){
      stop("FATAL ERROR! ","Cannot find highlighted element ", curr.highlight," in the highlight list!");
   }
  
  #plotParams <- new("QoRT_Plotter");
  #plotParams@res <- res;
  #plotParams@plot.type <- plot.type;
  title.highlight.name <- curr.highlight;
  showLegend <- compiled.params@showLegend;
  nvc.colors <- compiled.params@nvc.colors;
  nvc.colors.light <- compiled.params@nvc.colors.light;
  
  is.highlighted <- highlight.by == curr.highlight;
  lanebam.ct <- length(highlight.by);
  hl.by.factor <- color.highlighted.by[is.highlighted ];
  hl.by.factor.levels <- sort(unique(hl.by.factor));
  
  if(length(hl.by.factor.levels) > length(compiled.params@by.colors)) {
    message("WARNING WARNING WARNING: Too many categories to color! (Max = ",length(compiled.params@by.colors),", curr = ",length(hl.by.factor.levels),") Add more colors? Falling back to a rainbow palette");
    compiled.params@by.colors <- rainbow(length(hl.by.factor.levels));
  } 
  if(pch.matched.with.color){
    if(length(hl.by.factor.levels) > length(compiled.params@by.pch)){
      message("WARNING WARNING WARNING: Too many categories to mark distinct with pch! (Max = ",length(compiled.params@by.pch),", curr = ",length(hl.by.factor.levels),") Add more colors? Falling back to a repeating pattern.");
      compiled.params@by.pch <- rep(compiled.params@by.pch, ceiling( length(hl.by.factor.levels) / length(compiled.params@by.pch)));
    }
    legend.points.pch <- compiled.params@by.pch[1:length(hl.by.factor.levels)];
  } else {
    legend.points.pch <- rep(compiled.params@highlight.points.pch[1], length(hl.by.factor.levels));
  }

  legend.params <- data.frame(name = c(hl.by.factor.levels, paste0("Other ",highlighted.by.name)),
                                         lines.col = c(compiled.params@by.colors[1:length(hl.by.factor.levels)], compiled.params@highlight.color[2]),
                                         lines.lty = c(rep(compiled.params@highlight.lines.lty[1],length(hl.by.factor.levels)), compiled.params@highlight.lines.lty[2]),
                                         points.pch = c(legend.points.pch, compiled.params@highlight.points.pch[2]),
                                         points.col = c(compiled.params@by.colors[1:length(hl.by.factor.levels)], compiled.params@highlight.color[2]),
                                         stringsAsFactors=F
  );
  
  lines.col <- sapply(1:lanebam.ct, FUN=function(i){
    if(! is.highlighted[i]){ return(compiled.params@highlight.color[2]);
    } else {return( legend.params$lines.col[ legend.params$name == color.highlighted.by[i] ] );}
  });
  points.col <- sapply(1:lanebam.ct, FUN=function(i){
    if(! is.highlighted[i]){ return(compiled.params@highlight.color[2]);
    } else {return( legend.params$points.col[ legend.params$name == color.highlighted.by[i] ] );}
  });

  if(pch.matched.with.color){
    #message("!!!");
    if(length(hl.by.factor.levels) > length(compiled.params@by.pch)) stop("to many categories in by.colors! Add more pch values to compiled.params@by.pch!");
    points.pch <- sapply(1:lanebam.ct, FUN=function(i){
      if(! is.highlighted[i]){ return(compiled.params@highlight.points.pch[2]);
      } else {return( legend.params$points.pch[ legend.params$name == color.highlighted.by[i] ] );}
    });
    #message(paste("compiled.params@highlight.points.pch: ",compiled.params@highlight.points.pch,collapse=","));
    #message(paste("compiled.params@highlight.points.pch: ",compiled.params@highlight.points.pch,collapse=","));
    #message(paste("points.pch: ",points.pch,collapse=","));
  } else {
    points.pch <- ifelse(is.highlighted, compiled.params@highlight.points.pch[1], compiled.params@highlight.points.pch[2])
  }


  
  if(merge.offset.outgroup){
    offset.by.vals <- sort(unique(offset.by[is.highlighted]));
    if( all(offset.by %in% offset.by.vals)){
      offset.ct <- length(offset.by.vals) ;
    } else {
      offset.ct <- length(offset.by.vals) + 1;
    }
  } else {
    offset.by.vals <- sort(unique(offset.by));
    offset.ct <- length(offset.by.vals) ;
  }
  if(offset.ct %% 2 == 0){
    offsets <- (((1:offset.ct) / (offset.ct)) );
    offsets <- offsets - ( offsets[ offset.ct / 2  + 1] + offsets[ offset.ct / 2 ]  ) / 2
  } else {
    offsets <- (((1:offset.ct) / (offset.ct)) - 0.5  );
    offsets <- offsets - offsets[ (offset.ct + 1) / 2 ];
  }
  
  lanebam.offset.indices <- sapply(1:lanebam.ct, FUN=function(i){
    if(any(offset.by.vals == offset.by[i])){
      which(offset.by.vals == offset.by[i]);
    } else {
      offset.ct;
    }
  });
  lanebam.offsets <- offsets[lanebam.offset.indices];

  lanebam.params <- data.frame( plot.priority = ifelse(is.highlighted, 2,1),
                                           unique.ID = res@decoder$unique.ID,
                                           lines.col = lines.col,
                                           points.col = points.col,
                                           points.pch = points.pch,
                                           lines.lty = ifelse(is.highlighted, compiled.params@highlight.lines.lty[1], compiled.params@highlight.lines.lty[2]),
                                           lines.lwd = ifelse(is.highlighted, compiled.params@highlight.lines.lwd[1], compiled.params@highlight.lines.lwd[2]),
                                           lines.alpha = ifelse(is.highlighted, compiled.params@highlight.lines.alpha[1], compiled.params@highlight.lines.alpha[2]),
                                           points.alpha = ifelse(is.highlighted, compiled.params@highlight.points.alpha[1], compiled.params@highlight.points.alpha[2]),
                                           horiz.offsets = lanebam.offsets,
                                           vert.offsets = lanebam.offsets,
                                           stringsAsFactors=F
  );
  lanebam.params$lines.tcol  <- color2transparent(lanebam.params$lines.col,lanebam.params$lines.alpha);
  lanebam.params$points.tcol <- color2transparent(lanebam.params$points.col,lanebam.params$points.alpha);
  
  plotParams <- generate.plotter(res = res, plot.type = plot.type, title.highlight.name = title.highlight.name, legend.params = legend.params, showLegend = showLegend, nvc.colors = nvc.colors, nvc.colors.light = nvc.colors.light, lanebam.params = lanebam.params,randomize.plot.order=compiled.params@randomize.plot.order,
                                 title.annotations=c(title.annotations,compiled.params@plot.annotation))
  return(plotParams);
}

##################################################################################################################
##################################################################################################################
##################################################################################################################

#curr.highlight
#highlight.by
#color.highlighted.by
build.plotter.color <- function(res, compiled.params, color.by, plot.type, offset.by = color.by, merge.offset.outgroup = TRUE, pch.matched.with.color = TRUE, color.by.title.name = "",title.annotations=list()){
  if(! is.null(check.isValid(res))){
    #THROW AN ERROR!
    stop("Error parsing results: ", check.isValid(res));
  }
  
  #if(length(highlight.by) != length(color.by)) stop("error!");
  #if(length(highlight.by) != length(res@decoder$unique.ID)) stop("error!");

  
  #plotParams <- new("QoRT_Plotter");
  #plotParams@res <- res;
  #plotParams@plot.type <- plot.type;
  #title.highlight.name <- curr.highlight;
  showLegend <- compiled.params@showLegend;
  nvc.colors <- compiled.params@nvc.colors;
  nvc.colors.light <- compiled.params@nvc.colors.light;
  
  is.highlighted <- rep(TRUE,length(color.by))
  lanebam.ct <- length(color.by);
  hl.by.factor <- color.by[is.highlighted ];
  hl.by.factor.levels <- sort(unique(hl.by.factor));
  
  if(length(hl.by.factor.levels) > length(compiled.params@by.colors)) {
    message("WARNING WARNING WARNING: Too many categories to color! (Max = ",length(compiled.params@by.colors),", curr = ",length(hl.by.factor.levels),") Add more colors? Falling back to a rainbow palette");
    compiled.params@by.colors <- rainbow(length(hl.by.factor.levels));
  }
  
  if(pch.matched.with.color){
    if(length(hl.by.factor.levels) > length(compiled.params@by.pch)){
      message("WARNING WARNING WARNING: Too many categories to mark distinct with pch! Ran out of R symbols and ASCII characters! (Max = ",length(compiled.params@by.pch),", curr = ",length(hl.by.factor.levels),") Add more characters? Falling back to a repeating pattern.");
      compiled.params@by.pch <- rep(compiled.params@by.pch, ceiling( length(hl.by.factor.levels) / length(compiled.params@by.pch)));
    }
    legend.points.pch <- compiled.params@by.pch[1:length(hl.by.factor.levels)];
  } else {
    legend.points.pch <- rep(compiled.params@highlight.points.pch[1], length(hl.by.factor.levels));
  }

  legend.params <- data.frame(name = hl.by.factor.levels,
                                         lines.col = compiled.params@by.colors[1:length(hl.by.factor.levels)],
                                         lines.lty = rep(compiled.params@highlight.lines.lty[1],length(hl.by.factor.levels)),
                                         points.pch = legend.points.pch,
                                         points.col = compiled.params@by.colors[1:length(hl.by.factor.levels)],
                                         stringsAsFactors=F
  );
  
  lines.col <- sapply(1:lanebam.ct, FUN=function(i){
    if(! is.highlighted[i]){ return(compiled.params@highlight.color[2]);
    } else {return( legend.params$lines.col[ legend.params$name == color.by[i] ] );}
  });
  points.col <- sapply(1:lanebam.ct, FUN=function(i){
    if(! is.highlighted[i]){ return(compiled.params@highlight.color[2]);
    } else {return( legend.params$points.col[ legend.params$name == color.by[i] ] );}
  });

  if(pch.matched.with.color){
    #message("!!!");
    if(length(hl.by.factor.levels) > length(compiled.params@by.pch)) stop("to many categories in by.colors! Add more pch values to compiled.params@by.pch!");
    points.pch <- sapply(1:lanebam.ct, FUN=function(i){
      if(! is.highlighted[i]){ return(compiled.params@highlight.points.pch[2]);
      } else {return( legend.params$points.pch[ legend.params$name == color.by[i] ] );}
    });
    #message(paste("compiled.params@highlight.points.pch: ",compiled.params@highlight.points.pch,collapse=","));
    #message(paste("compiled.params@highlight.points.pch: ",compiled.params@highlight.points.pch,collapse=","));
    #message(paste("points.pch: ",points.pch,collapse=","));
  } else {
    points.pch <- ifelse(is.highlighted, compiled.params@highlight.points.pch[1], compiled.params@highlight.points.pch[2])
  }

  if(merge.offset.outgroup){
    offset.by.vals <- sort(unique(offset.by[is.highlighted]));
    if( all(offset.by %in% offset.by.vals)){
      offset.ct <- length(offset.by.vals) ;
    } else {
      offset.ct <- length(offset.by.vals) + 1;
    }
  } else {
    offset.by.vals <- sort(unique(offset.by));
    offset.ct <- length(offset.by.vals) ;
  }
  if(offset.ct %% 2 == 0){
    offsets <- (((1:offset.ct) / (offset.ct)) );
    offsets <- offsets - ( offsets[ offset.ct / 2  + 1] + offsets[ offset.ct / 2 ]  ) / 2
  } else {
    offsets <- (((1:offset.ct) / (offset.ct)) - 0.5  );
    offsets <- offsets - offsets[ (offset.ct + 1) / 2 ];
  }
  
  lanebam.offset.indices <- sapply(1:lanebam.ct, FUN=function(i){
    if(any(offset.by.vals == offset.by[i])){
      which(offset.by.vals == offset.by[i]);
    } else {
      offset.ct;
    }
  });
  lanebam.offsets <- offsets[lanebam.offset.indices];

  lanebam.params <- data.frame( plot.priority = ifelse(is.highlighted, 2,1),
                                           unique.ID = res@decoder$unique.ID,
                                           lines.col = lines.col,
                                           points.col = points.col,
                                           points.pch = points.pch,
                                           lines.lty = ifelse(is.highlighted, compiled.params@highlight.lines.lty[1], compiled.params@highlight.lines.lty[2]),
                                           lines.lwd = ifelse(is.highlighted, compiled.params@highlight.lines.lwd[1], compiled.params@highlight.lines.lwd[2]),
                                           lines.alpha = ifelse(is.highlighted, compiled.params@highlight.lines.alpha[1], compiled.params@highlight.lines.alpha[2]),
                                           points.alpha = ifelse(is.highlighted, compiled.params@highlight.points.alpha[1], compiled.params@highlight.points.alpha[2]),
                                           horiz.offsets = lanebam.offsets,
                                           vert.offsets = lanebam.offsets,
                                           stringsAsFactors=F
  );
  lanebam.params$lines.tcol  <- color2transparent(lanebam.params$lines.col,lanebam.params$lines.alpha);
  lanebam.params$points.tcol <- color2transparent(lanebam.params$points.col,lanebam.params$points.alpha);
  
  plotParams <- generate.plotter(res = res, plot.type = plot.type, title.highlight.name = color.by.title.name, legend.params = legend.params, showLegend = showLegend, nvc.colors = nvc.colors, nvc.colors.light = nvc.colors.light, lanebam.params = lanebam.params,randomize.plot.order=compiled.params@randomize.plot.order,
                                 title.annotations=c(title.annotations,compiled.params@plot.annotation))
  return(plotParams);
}

##################################################################################################################
##################################################################################################################
##################################################################################################################

build.plotter.highlight.OLD <- function(curr.highlight, res, compiled.params, highlight.by, plot.type, offset.by, merge.offset.outgroup = TRUE){
  if(! is.null(check.isValid(res))){
    #THROW AN ERROR!
    stop("Error parsing results: ", check.isValid(res));
  }
  if(length(highlight.by) != length(res@decoder$unique.ID)) stop("error!");
   if(! (curr.highlight %in% highlight.by)){
      stop("FATAL ERROR! ","Cannot find highlighted element ", curr.highlight," in the highlight list!");
   }
  
  #hl.color <- compiled.params@highlight.color;

  #plotParams <- new("QoRT_Plotter");
  #plotParams@res <- res;
  #plotParams@plot.type <- plot.type;
  title.highlight.name <- curr.highlight;
  showLegend <- compiled.params@showLegend;
  nvc.colors <- compiled.params@nvc.colors;
  nvc.colors.light <- compiled.params@nvc.colors.light;
  
  is.highlighted <- highlight.by == curr.highlight;
  lanebam.ct <- length(highlight.by);
  
  legend.params <- data.frame(name = c(curr.highlight,"Other Samples"),
                                         lines.col = compiled.params@highlight.color,
                                         lines.lty = compiled.params@highlight.lines.lty,
                                         points.pch = compiled.params@highlight.points.pch,
                                         points.col = compiled.params@highlight.color,
                                         stringsAsFactors=F
  );
  if(merge.offset.outgroup){
    offset.by.vals <- sort(unique(offset.by[is.highlighted]));
    if( all(offset.by %in% offset.by.vals)){
      offset.ct <- length(offset.by.vals) ;
    } else {
      offset.ct <- length(offset.by.vals) + 1;
    }
  } else {
    offset.by.vals <- sort(unique(offset.by));
    offset.ct <- length(offset.by.vals) ;
  }
  if(offset.ct %% 2 == 0){
    offsets <- (((1:offset.ct) / (offset.ct)) );
    offsets <- offsets - ( offsets[ offset.ct / 2  + 1] + offsets[ offset.ct / 2 ]  ) / 2
  } else {
    offsets <- (((1:offset.ct) / (offset.ct)) - 0.5  );
    offsets <- offsets - offsets[ (offset.ct + 1) / 2 ];
  }
  
  lanebam.offset.indices <- sapply(1:lanebam.ct, FUN=function(i){
    if(any(offset.by.vals == offset.by[i])){
      which(offset.by.vals == offset.by[i]);
    } else {
      offset.ct;
    }
  });
  lanebam.offsets <- offsets[lanebam.offset.indices];
  
  
  lanebam.params <- data.frame( plot.priority = ifelse(is.highlighted, 2,1),
                                           unique.ID = res@decoder$unique.ID,
                                           lines.col = ifelse(is.highlighted, compiled.params@highlight.color[1], compiled.params@highlight.color[2]),
                                           points.col = ifelse(is.highlighted, compiled.params@highlight.color[1], compiled.params@highlight.color[2]),
                                           points.pch = ifelse(is.highlighted, compiled.params@highlight.points.pch[1], compiled.params@highlight.points.pch[2]),
                                           lines.lty = ifelse(is.highlighted, compiled.params@highlight.lines.lty[1], compiled.params@highlight.lines.lty[2]),
                                           lines.lwd = ifelse(is.highlighted, compiled.params@highlight.lines.lwd[1], compiled.params@highlight.lines.lwd[2]),
                                           lines.alpha = ifelse(is.highlighted, compiled.params@highlight.lines.alpha[1], compiled.params@highlight.lines.alpha[2]),
                                           points.alpha = ifelse(is.highlighted, compiled.params@highlight.points.alpha[1], compiled.params@highlight.points.alpha[2]),
                                           horiz.offsets = lanebam.offsets,
                                           vert.offsets = lanebam.offsets,
                                           stringsAsFactors=F
  );
  lanebam.params$lines.tcol  <- color2transparent(lanebam.params$lines.col,lanebam.params$lines.alpha);
  lanebam.params$points.tcol <- color2transparent(lanebam.params$points.col,lanebam.params$points.alpha);
  
  plotParams <- generate.plotter(res = res, plot.type = plot.type, title.highlight.name = title.highlight.name, legend.params = legend.params, showLegend = showLegend, nvc.colors = nvc.colors, nvc.colors.light = nvc.colors.light, lanebam.params = lanebam.params,randomize.plot.order=compiled.params@randomize.plot.order,
                                 title.annotations=c(title.annotations,compiled.params@plot.annotation))
  return(plotParams);
}


build.plotter.highlight <- function(curr.highlight, res, 
                                    title.highlight.name=curr.highlight, compiled.params, highlight.by, plot.type, offset.by, merge.offset.outgroup = TRUE,title.annotations=list(),
                                    outgroup.name = "Other",
                                    highlightTitle.plural = "Samples", highlightTitle.singular = "Sample"){
  if(! is.null(check.isValid(res))){
    #THROW AN ERROR!
    stop("Error parsing results: ", check.isValid(res));
  }
  if(length(highlight.by) != length(res@decoder$unique.ID)) stop("error!");
   if(! all(curr.highlight %in% highlight.by)){
      stop("FATAL ERROR! ","Cannot find one or more highlighted elements in the highlight list!");
   }
  
  #hl.color <- compiled.params@highlight.color;

  #plotParams <- new("QoRT_Plotter");
  #plotParams@res <- res;
  #plotParams@plot.type <- plot.type;
  
  #title.highlight.name <- highlight.name;
  showLegend <- compiled.params@showLegend;
  nvc.colors <- compiled.params@nvc.colors;
  nvc.colors.light <- compiled.params@nvc.colors.light;
  
  is.highlighted <- highlight.by %in% curr.highlight;
  lanebam.ct <- length(highlight.by);
  
  legend.params <- data.frame(name = c(title.highlight.name,paste0(outgroup.name," ",highlightTitle.plural)),
                                         lines.col = compiled.params@highlight.color,
                                         lines.lty = compiled.params@highlight.lines.lty,
                                         points.pch = compiled.params@highlight.points.pch,
                                         points.col = compiled.params@highlight.color,
                                         stringsAsFactors=F
  );
  if(merge.offset.outgroup){
    offset.by.vals <- sort(unique(offset.by[is.highlighted]));
    if( all(offset.by %in% offset.by.vals)){
      offset.ct <- length(offset.by.vals) ;
    } else {
      offset.ct <- length(offset.by.vals) + 1;
    }
  } else {
    offset.by.vals <- sort(unique(offset.by));
    offset.ct <- length(offset.by.vals) ;
  }
  if(offset.ct %% 2 == 0){
    offsets <- (((1:offset.ct) / (offset.ct)) );
    offsets <- offsets - ( offsets[ offset.ct / 2  + 1] + offsets[ offset.ct / 2 ]  ) / 2
  } else {
    offsets <- (((1:offset.ct) / (offset.ct)) - 0.5  );
    offsets <- offsets - offsets[ (offset.ct + 1) / 2 ];
  }
  
  lanebam.offset.indices <- sapply(1:lanebam.ct, FUN=function(i){
    if(any(offset.by.vals == offset.by[i])){
      which(offset.by.vals == offset.by[i]);
    } else {
      offset.ct;
    }
  });
  lanebam.offsets <- offsets[lanebam.offset.indices];
  
  
  lanebam.params <- data.frame( plot.priority = ifelse(is.highlighted, 2,1),
                               unique.ID = res@decoder$unique.ID,
                               lines.col = ifelse(is.highlighted, compiled.params@highlight.color[1], compiled.params@highlight.color[2]),
                               points.col = ifelse(is.highlighted, compiled.params@highlight.color[1], compiled.params@highlight.color[2]),
                               points.pch = ifelse(is.highlighted, compiled.params@highlight.points.pch[1], compiled.params@highlight.points.pch[2]),
                               lines.lty = ifelse(is.highlighted, compiled.params@highlight.lines.lty[1], compiled.params@highlight.lines.lty[2]),
                               lines.lwd = ifelse(is.highlighted, compiled.params@highlight.lines.lwd[1], compiled.params@highlight.lines.lwd[2]),
                               lines.alpha = ifelse(is.highlighted, compiled.params@highlight.lines.alpha[1], compiled.params@highlight.lines.alpha[2]),
                               points.alpha = ifelse(is.highlighted, compiled.params@highlight.points.alpha[1], compiled.params@highlight.points.alpha[2]),
                               horiz.offsets = lanebam.offsets,
                               vert.offsets = lanebam.offsets,
                               stringsAsFactors=F
  );
  lanebam.params$lines.tcol  <- color2transparent(lanebam.params$lines.col,lanebam.params$lines.alpha);
  lanebam.params$points.tcol <- color2transparent(lanebam.params$points.col,lanebam.params$points.alpha);
  
  plotParams <- generate.plotter(res = res, plot.type = plot.type, 
                                 title.highlight.name = title.highlight.name, 
                                 legend.params = legend.params, showLegend = showLegend, 
                                 nvc.colors = nvc.colors, nvc.colors.light = nvc.colors.light, 
                                 lanebam.params = lanebam.params,
                                 randomize.plot.order=compiled.params@randomize.plot.order,
                                 title.annotations=c(title.annotations,compiled.params@plot.annotation))
  return(plotParams);
}

##################################################################################################################
##################################################################################################################
##################################################################################################################

