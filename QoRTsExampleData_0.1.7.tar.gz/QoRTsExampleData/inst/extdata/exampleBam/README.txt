Example .bam files not included in this package, due to file size constraints.

Example bams can be found on the github website:
https://github.com/hartleys/QoRTs

