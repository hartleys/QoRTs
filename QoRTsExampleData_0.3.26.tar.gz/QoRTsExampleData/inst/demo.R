require("QoRT");
require("QoRTexampleData");

directory <- system.file("extdata/", package="QoRTexampleData", mustWork=TRUE);
decoder.file <- system.file("extdata/decoder.txt", package="QoRTexampleData", mustWork=TRUE);
decoder.data <- read.table(decoder.file,header=T,stringsAsFactors=F);

print(decoder.data);

paste0(directory,decoder.data$qc.data.dir)

res <- read.qc.results.data(directory, decoder.data.frame = decoder.data);

outfile.dir <- "./"

plot.summary.basic(res, outfile.prefix = outfile.dir, plot.device.name = "CairoPNG");

plot.summary.colorByGroup(res, outfile.prefix = outfile.dir, plot.device.name = "CairoPNG");

plot.summary.colorByLane(res, outfile.prefix = outfile.dir, plot.device.name = "CairoPNG");

plot.summary.sample.highlight.all(res,outfile.dir);

