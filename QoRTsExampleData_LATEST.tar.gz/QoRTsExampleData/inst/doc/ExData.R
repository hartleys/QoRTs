## ----knitr, echo=FALSE, results="hide"-----------------------------------
library("knitr")
library("Cairo")
opts_chunk$set(tidy=FALSE,dev="CairoPNG",fig.show="hide",
               fig.width=6.5,fig.height=5.5,fig.keep="high",
               message=FALSE)

## ----style, eval=TRUE, echo=FALSE, results="asis"---------------------------------------
BiocStyle::latex()

## ----setup,echo=FALSE,results="hide"------------------------------------------
options(width=80, signif=3, digits=3, prompt=" ", continue=" ")
set.seed(0xdada)
require("QoRTs")

## ----GetExampleDataDirectory--------------------------------------------------
directory <- system.file("extdata/", package="QoRTsExampleData", 
                         mustWork=TRUE);
decoder.file <- system.file("extdata/decoder.txt", 
                            package="QoRTsExampleData", 
                            mustWork=TRUE);
decoder.data <- read.table(decoder.file,
                           header=T,
                           stringsAsFactors=F);
print(decoder.data);

## ----sessionInfo--------------------------------------------------------------
sessionInfo()

