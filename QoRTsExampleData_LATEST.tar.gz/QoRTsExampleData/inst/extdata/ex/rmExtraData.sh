#This simple script removes the large, unnecessary data files that are not used in the QoRTs examples and vignette.

rm -rf ./*/QCplots/
rm ./*/QC.makeMultiplot.R
rm ./*/QC.makeMultiplot.Rlog
rm ./*/QC.multiPlot.pdf
rm ./*/QC.multiPlot.png
rm ./*/QC.spliceJunction*
rm ./*/QC.wiggle.*
rm ./*/QC.geneBodyCoverage.DEBUG.intervals.txt.gz
rm ./*/QC.geneBodyCoverage.genewise.txt.gz
rm ./*/QC.junctionBed.known.bed.gz
rm ./*/QC.exonCounts.formatted.for.DEXSeq.txt.gz

