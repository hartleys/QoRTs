rm -rf /home/hartleys/UTILS/R/QoRTsExampleData/inst/extdata/ex/*
cp -r /cluster/ifs/users/mullikin/Klein/steve/projects/ZZZ-ExampleDataset/TestSets/TestSets/DsetExample2/outputData/qortsData/* ./ex/

cd ex

rm -rf ./*/QCplots/
rm ./*/QC.makeMultiplot.R
rm ./*/QC.makeMultiplot.Rlog
rm ./*/QC.multiPlot.pdf
rm ./*/QC.multiPlot.png
rm ./*/QC.spliceJunction*
rm ./*/QC.wiggle.*
rm ./*/QC.geneBodyCoverage.DEBUG.intervals.txt.gz
rm ./*/QC.geneBodyCoverage.genewise.txt.gz
rm ./*/QC.junctionBed.known.bed.gz
rm ./*/QC.exonCounts.formatted.for.DEXSeq.txt.gz

